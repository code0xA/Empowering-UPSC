MCA  Major  Project

Developed  a  dynamic  and  responsive  web  platform  for  UPSC  aspirants  using  React.js,  HTML,  CSS,  and  JavaScript for  Frontend  and  Node.js  with  Express.js  for  Backend.   And  Integrated  MongoDB  for  efficient  data  storage  and retrieval,  and  implemented  a  Programmed  Chatbot  for  mentorship  and  guidance.
